-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema Ejer7Matricula
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema Ejer7Matricula
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `Ejer7Matricula` DEFAULT CHARACTER SET utf8mb4 ;
USE `Ejer7Matricula` ;

-- -----------------------------------------------------
-- Table `Ejer7Matricula`.`CODICURSO`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Ejer7Matricula`.`CODICURSO` (
  `IDCODICURSO` INT NOT NULL,
  `CODICURSO` VARCHAR(5) NOT NULL,
  `NOMICURSO` VARCHAR(32) NOT NULL,
  PRIMARY KEY (`IDCODICURSO`));


-- -----------------------------------------------------
-- Table `Ejer7Matricula`.`PROFESOR`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Ejer7Matricula`.`PROFESOR` (
  `IDPROFE` INT NOT NULL,
  `NOMPROFE` VARCHAR(255) NOT NULL,
  `TELPROFE` VARCHAR(9) NOT NULL,
  `OFICINA` VARCHAR(5) NOT NULL,
  `CODICURSO_IDCODICURSO` INT NOT NULL,
  PRIMARY KEY (`IDPROFE`),
  UNIQUE INDEX `IDPROFE_UNIQUE` (`IDPROFE` ASC),
  INDEX `fk_PROFESOR_user1_idx` (`CODICURSO_IDCODICURSO` ASC),
  CONSTRAINT `fk_PROFESOR_user1`
    FOREIGN KEY (`CODICURSO_IDCODICURSO`)
    REFERENCES `Ejer7Matricula`.`CODICURSO` (`IDCODICURSO`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION);


-- -----------------------------------------------------
-- Table `Ejer7Matricula`.`ALUMNO`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Ejer7Matricula`.`ALUMNO` (
  `IDALUMNO` INT NOT NULL,
  `NOMALUMNO` VARCHAR(45) NOT NULL,
  `FECHNACALUMNO` DATE NOT NULL,
  `CODALUMNO` VARCHAR(5) NOT NULL,
  `TELFALUMNO` VARCHAR(9) NOT NULL,
  PRIMARY KEY (`IDALUMNO`),
  UNIQUE INDEX `IDAULA_UNIQUE` (`IDALUMNO` ASC))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Ejer7Matricula`.`CURSO`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Ejer7Matricula`.`CURSO` (
  `idCURSO` INT NOT NULL,
  `NOMCURSO` VARCHAR(45) NULL,
  PRIMARY KEY (`idCURSO`),
  UNIQUE INDEX `idCURSO_UNIQUE` (`idCURSO` ASC))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Ejer7Matricula`.`ESPECIALIDAD`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Ejer7Matricula`.`ESPECIALIDAD` (
  `IDESPECIALIDAD` INT NOT NULL,
  `ESPECIALIDAD` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`IDESPECIALIDAD`),
  UNIQUE INDEX `IDEDIT_UNIQUE` (`IDESPECIALIDAD` ASC))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Ejer7Matricula`.`MATRICULA`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Ejer7Matricula`.`MATRICULA` (
  `IDMATRICULA` INT NOT NULL,
  `FECHAINIMATRICULA` DATE NOT NULL,
  `FECHAFINMATRICULA` DATE NULL,
  `ALUMNO_IDALUMNO` INT NOT NULL,
  `CURSO_idCURSO` INT NOT NULL,
  `ESPECIALIDAD_IDESPECIALIDAD` INT NOT NULL,
  `PROFESOR_IDPROFE` INT NOT NULL,
  PRIMARY KEY (`IDMATRICULA`),
  UNIQUE INDEX `IDPRESTA_UNIQUE` (`IDMATRICULA` ASC),
  INDEX `fk_MATRICULA_ALUMNO1_idx` (`ALUMNO_IDALUMNO` ASC),
  INDEX `fk_MATRICULA_CURSO1_idx` (`CURSO_idCURSO` ASC),
  INDEX `fk_MATRICULA_ESPECIALIDAD1_idx` (`ESPECIALIDAD_IDESPECIALIDAD` ASC),
  INDEX `fk_MATRICULA_PROFESOR1_idx` (`PROFESOR_IDPROFE` ASC),
  CONSTRAINT `fk_MATRICULA_ALUMNO1`
    FOREIGN KEY (`ALUMNO_IDALUMNO`)
    REFERENCES `Ejer7Matricula`.`ALUMNO` (`IDALUMNO`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_MATRICULA_CURSO1`
    FOREIGN KEY (`CURSO_idCURSO`)
    REFERENCES `Ejer7Matricula`.`CURSO` (`idCURSO`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_MATRICULA_ESPECIALIDAD1`
    FOREIGN KEY (`ESPECIALIDAD_IDESPECIALIDAD`)
    REFERENCES `Ejer7Matricula`.`ESPECIALIDAD` (`IDESPECIALIDAD`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_MATRICULA_PROFESOR1`
    FOREIGN KEY (`PROFESOR_IDPROFE`)
    REFERENCES `Ejer7Matricula`.`PROFESOR` (`IDPROFE`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
