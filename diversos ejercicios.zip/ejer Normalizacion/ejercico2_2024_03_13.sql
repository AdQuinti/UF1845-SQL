-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `mydb` DEFAULT CHARACTER SET utf8 ;
USE `mydb` ;

-- -----------------------------------------------------
-- Table `mydb`.`cliente`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`cliente` (
  `idcliente` INT NOT NULL,
  `namecliente` VARCHAR(45) NULL,
  PRIMARY KEY (`idcliente`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`comunidad`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`comunidad` (
  `idcomunidad` INT NOT NULL,
  `comunidad` VARCHAR(45) NULL,
  `cliente_idcliente` INT NOT NULL,
  PRIMARY KEY (`idcomunidad`),
  INDEX `fk_comunidad_cliente1_idx` (`cliente_idcliente` ASC),
  CONSTRAINT `fk_comunidad_cliente1`
    FOREIGN KEY (`cliente_idcliente`)
    REFERENCES `mydb`.`cliente` (`idcliente`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`Producto`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`Producto` (
  `Num_art` INT NOT NULL,
  `nom_art` VARCHAR(45) NULL,
  PRIMARY KEY (`Num_art`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`orden`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`orden` (
  `id_orden` INT NOT NULL,
  `fecha` VARCHAR(45) NULL,
  PRIMARY KEY (`id_orden`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`factura`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`factura` (
  `idfactura` INT NOT NULL,
  `cantidad` INT NULL,
  `precio` DECIMAL NULL,
  `Producto_Num_art` INT NOT NULL,
  `cliente_idcliente` INT NOT NULL,
  `factura_id_orden` INT NOT NULL,
  PRIMARY KEY (`idfactura`),
  INDEX `fk_factura_Producto1_idx` (`Producto_Num_art` ASC),
  INDEX `fk_factura_cliente1_idx` (`cliente_idcliente` ASC),
  INDEX `fk_factura_factura1_idx` (`factura_id_orden` ASC),
  CONSTRAINT `fk_factura_Producto1`
    FOREIGN KEY (`Producto_Num_art`)
    REFERENCES `mydb`.`Producto` (`Num_art`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_factura_cliente1`
    FOREIGN KEY (`cliente_idcliente`)
    REFERENCES `mydb`.`cliente` (`idcliente`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_factura_factura1`
    FOREIGN KEY (`factura_id_orden`)
    REFERENCES `mydb`.`orden` (`id_orden`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
