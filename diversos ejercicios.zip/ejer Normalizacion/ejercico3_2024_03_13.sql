-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `mydb` DEFAULT CHARACTER SET utf8 ;
USE `mydb` ;

-- -----------------------------------------------------
-- Table `mydb`.`CATEGORIA`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`CATEGORIA` (
  `idCATEGORIA` INT NOT NULL,
  `NOM_CATEGORIA` VARCHAR(45) NULL,
  PRIMARY KEY (`idCATEGORIA`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`PRODUCTO`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`PRODUCTO` (
  `COD_PRODUCTO` INT NOT NULL,
  `DESCRIPCION` VARCHAR(45) NULL,
  `VAL_UNID` INT NULL,
  `CATEGORIA_idCATEGORIA` INT NOT NULL,
  PRIMARY KEY (`COD_PRODUCTO`),
  INDEX `fk_PRODUCTO_CATEGORIA_idx` (`CATEGORIA_idCATEGORIA` ASC),
  CONSTRAINT `fk_PRODUCTO_CATEGORIA`
    FOREIGN KEY (`CATEGORIA_idCATEGORIA`)
    REFERENCES `mydb`.`CATEGORIA` (`idCATEGORIA`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`TELEFONO`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`TELEFONO` (
  `idTELEF` INT NOT NULL,
  `NUM1_TELEF` INT NULL,
  PRIMARY KEY (`idTELEF`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`CIUDAD`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`CIUDAD` (
  `idCIUDAD` INT NOT NULL,
  `NOM_CIUDAD` VARCHAR(45) NULL,
  PRIMARY KEY (`idCIUDAD`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`DIRECCION`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`DIRECCION` (
  `idDIRECCION` INT NOT NULL,
  `DIRECCION` VARCHAR(45) NULL,
  `CIUDAD_idCIUDAD` INT NOT NULL,
  PRIMARY KEY (`idDIRECCION`),
  INDEX `fk_DIRECCION_CIUDAD1_idx` (`CIUDAD_idCIUDAD` ASC),
  CONSTRAINT `fk_DIRECCION_CIUDAD1`
    FOREIGN KEY (`CIUDAD_idCIUDAD`)
    REFERENCES `mydb`.`CIUDAD` (`idCIUDAD`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`CLIENTE`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`CLIENTE` (
  `CIF_CLIENTE` INT NOT NULL,
  `NOM_CLIENTE` VARCHAR(45) NULL,
  `TELEFONO_idTELEF` INT NOT NULL,
  `DIRECCION_idDIRECCION` INT NOT NULL,
  PRIMARY KEY (`CIF_CLIENTE`),
  INDEX `fk_CLIENTE_TELEFONO1_idx` (`TELEFONO_idTELEF` ASC),
  INDEX `fk_CLIENTE_DIRECCION1_idx` (`DIRECCION_idDIRECCION` ASC),
  CONSTRAINT `fk_CLIENTE_TELEFONO1`
    FOREIGN KEY (`TELEFONO_idTELEF`)
    REFERENCES `mydb`.`TELEFONO` (`idTELEF`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_CLIENTE_DIRECCION1`
    FOREIGN KEY (`DIRECCION_idDIRECCION`)
    REFERENCES `mydb`.`DIRECCION` (`idDIRECCION`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`FACTURA`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`FACTURA` (
  `NUM_FAC` INT NOT NULL,
  `FECHA_FAC` DATE NULL,
  `CANT_PROD` INT NULL,
  `PRODUCTO_COD_PRODUCTO` INT NOT NULL,
  `CLIENTE_CIF_CLIENTE` INT NOT NULL,
  PRIMARY KEY (`NUM_FAC`),
  INDEX `fk_FACTURA_PRODUCTO1_idx` (`PRODUCTO_COD_PRODUCTO` ASC),
  INDEX `fk_FACTURA_CLIENTE1_idx` (`CLIENTE_CIF_CLIENTE` ASC),
  CONSTRAINT `fk_FACTURA_PRODUCTO1`
    FOREIGN KEY (`PRODUCTO_COD_PRODUCTO`)
    REFERENCES `mydb`.`PRODUCTO` (`COD_PRODUCTO`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_FACTURA_CLIENTE1`
    FOREIGN KEY (`CLIENTE_CIF_CLIENTE`)
    REFERENCES `mydb`.`CLIENTE` (`CIF_CLIENTE`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
