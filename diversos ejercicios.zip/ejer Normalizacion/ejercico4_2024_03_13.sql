-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `mydb` DEFAULT CHARACTER SET utf8 ;
USE `mydb` ;

-- -----------------------------------------------------
-- Table `mydb`.`ACTIVIDAD`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`ACTIVIDAD` (
  `idACTIVIDAD` INT NOT NULL,
  `ACTIVIDAD` VARCHAR(45) NULL,
  PRIMARY KEY (`idACTIVIDAD`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`CIUDAD`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`CIUDAD` (
  `idCIUDAD` INT NOT NULL,
  `CIUDAD` VARCHAR(45) NULL,
  PRIMARY KEY (`idCIUDAD`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`ORIGEN`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`ORIGEN` (
  `ORGN_RIF` INT NOT NULL,
  `ORGN_NOM` VARCHAR(45) NULL,
  `ORGN_DIR` VARCHAR(45) NULL,
  `ACTIVIDAD_idACTIVIDAD` INT NOT NULL,
  `CIUDAD_idCIUDAD` INT NOT NULL,
  PRIMARY KEY (`ORGN_RIF`),
  INDEX `fk_ORIGEN_ACTIVIDAD1_idx` (`ACTIVIDAD_idACTIVIDAD` ASC),
  INDEX `fk_ORIGEN_CIUDAD1_idx` (`CIUDAD_idCIUDAD` ASC),
  CONSTRAINT `fk_ORIGEN_ACTIVIDAD1`
    FOREIGN KEY (`ACTIVIDAD_idACTIVIDAD`)
    REFERENCES `mydb`.`ACTIVIDAD` (`idACTIVIDAD`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_ORIGEN_CIUDAD1`
    FOREIGN KEY (`CIUDAD_idCIUDAD`)
    REFERENCES `mydb`.`CIUDAD` (`idCIUDAD`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`DESTINO`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`DESTINO` (
  `idDEST` INT NOT NULL,
  `NOM_DEST` VARCHAR(45) NULL,
  `DIR_DEST` VARCHAR(45) NULL,
  `KM_DEST` DECIMAL NULL,
  `CIUDAD_idCIUDAD` INT NOT NULL,
  PRIMARY KEY (`idDEST`),
  INDEX `fk_DESTINO_CIUDAD1_idx` (`CIUDAD_idCIUDAD` ASC),
  CONSTRAINT `fk_DESTINO_CIUDAD1`
    FOREIGN KEY (`CIUDAD_idCIUDAD`)
    REFERENCES `mydb`.`CIUDAD` (`idCIUDAD`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`TIPO`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`TIPO` (
  `idTIPO` INT NOT NULL,
  `TIPO` VARCHAR(45) NULL,
  PRIMARY KEY (`idTIPO`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`PAQUETE`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`PAQUETE` (
  `COD_PAQUETE` INT NOT NULL,
  `NOM_PAQUETE` VARCHAR(45) NULL,
  `DESCP_PAQUETE` VARCHAR(45) NULL,
  `TIPO_idTIPO` INT NOT NULL,
  PRIMARY KEY (`COD_PAQUETE`),
  INDEX `fk_PAQUETE_TIPO_idx` (`TIPO_idTIPO` ASC),
  CONSTRAINT `fk_PAQUETE_TIPO`
    FOREIGN KEY (`TIPO_idTIPO`)
    REFERENCES `mydb`.`TIPO` (`idTIPO`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`GUIA`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`GUIA` (
  `GUIA_NO` INT NOT NULL,
  `GUIA_FECHA` DATE NULL,
  `GUIA_HORA` TIME NULL,
  `VALR_FLETE` DECIMAL NULL,
  `ORIGEN_ORGN_RIF` INT NOT NULL,
  `DESTINO_idDEST` INT NOT NULL,
  `PAQUETE_COD_PAQUETE` INT NOT NULL,
  PRIMARY KEY (`GUIA_NO`),
  INDEX `fk_GUIA_ORIGEN1_idx` (`ORIGEN_ORGN_RIF` ASC),
  INDEX `fk_GUIA_DESTINO1_idx` (`DESTINO_idDEST` ASC),
  INDEX `fk_GUIA_PAQUETE1_idx` (`PAQUETE_COD_PAQUETE` ASC),
  CONSTRAINT `fk_GUIA_ORIGEN1`
    FOREIGN KEY (`ORIGEN_ORGN_RIF`)
    REFERENCES `mydb`.`ORIGEN` (`ORGN_RIF`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_GUIA_DESTINO1`
    FOREIGN KEY (`DESTINO_idDEST`)
    REFERENCES `mydb`.`DESTINO` (`idDEST`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_GUIA_PAQUETE1`
    FOREIGN KEY (`PAQUETE_COD_PAQUETE`)
    REFERENCES `mydb`.`PAQUETE` (`COD_PAQUETE`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`TELEFONO`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`TELEFONO` (
  `idTELF` INT NOT NULL,
  `TELEFONO` INT NULL,
  `CELULAR` INT NULL,
  `ORIGEN_ORGN_RIF` INT NOT NULL,
  `DESTINO_idDEST` INT NOT NULL,
  PRIMARY KEY (`idTELF`),
  INDEX `fk_TELEFONO_ORIGEN1_idx` (`ORIGEN_ORGN_RIF` ASC),
  INDEX `fk_TELEFONO_DESTINO1_idx` (`DESTINO_idDEST` ASC),
  CONSTRAINT `fk_TELEFONO_ORIGEN1`
    FOREIGN KEY (`ORIGEN_ORGN_RIF`)
    REFERENCES `mydb`.`ORIGEN` (`ORGN_RIF`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_TELEFONO_DESTINO1`
    FOREIGN KEY (`DESTINO_idDEST`)
    REFERENCES `mydb`.`DESTINO` (`idDEST`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
